var browser = (typeof browser === "undefined") ? chrome : browser;

const KEYS = [
    "stickRadius", "buttonDiameter", "buttonBorderOffset",
    "buttonBorderLeftOffset", "buttonBorderRightOffset",
    "buttonBorderTopOffset", "buttonBorderBottomOffset",
    "opacity", "enableColors", "enableDrawSticks", "disableTouchController",
    "enableGlow", "buttonConfig", "leftStickSensitivity", "rightStickSensitivity",
    "rightStickDeadzone", "fixedSticks", "fixedSticksOpacity", "fixedSticksPos",
    "buttonOverrides"
];

function showToast(msg) {
    const t = document.getElementById("toast");
    t.textContent = msg || "✓ Salvo!";
    t.classList.add("show");
    setTimeout(() => t.classList.remove("show"), 2000);
}

function getFormValues() {
    const offset = parseInt(document.getElementById("button-border-offset").value) || 1;
    return {
        stickRadius:              parseInt(document.getElementById("stick-radius").value),
        buttonDiameter:           parseInt(document.getElementById("button-diameter").value),
        buttonBorderOffset:       offset,
        buttonBorderLeftOffset:   offset,
        buttonBorderRightOffset:  offset,
        buttonBorderTopOffset:    offset,
        buttonBorderBottomOffset: offset,
        opacity:                  parseInt(document.getElementById("opacity").value),
        enableColors:             document.getElementById("enable-colors").checked,
        enableDrawSticks:         document.getElementById("enable-draw-sticks").checked,
        disableTouchController:   document.getElementById("disable-touchcontroller").checked,
        enableGlow:               document.getElementById("enable-glow").checked,
        leftStickSensitivity:     parseFloat(document.getElementById("left-sensitivity").value),
        rightStickSensitivity:    parseFloat(document.getElementById("right-sensitivity").value),
        rightStickDeadzone:       parseFloat(document.getElementById("right-deadzone").value),
    };
}

function setFormValues(s) {
    const set     = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
    const setText = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    const setChk  = (id, val) => { const el = document.getElementById(id); if (el) el.checked = !!val; };

    const sr = s.stickRadius || 40;
    set("stick-radius", sr); setText("val-stick-radius", sr);

    const bd = s.buttonDiameter || 50;
    set("button-diameter", bd); setText("val-button-diameter", bd);

    const op = s.opacity || 180;
    set("opacity", op); setText("val-opacity", op);

    const off = s.buttonBorderOffset || s.buttonBorderLeftOffset || 1;
    set("button-border-offset", off);

    const rs = s.rightStickSensitivity || 1.0;
    set("right-sensitivity", rs); setText("val-right-sens", parseFloat(rs).toFixed(2) + "×");

    const ls = s.leftStickSensitivity || 1.0;
    set("left-sensitivity", ls); setText("val-left-sens", parseFloat(ls).toFixed(2) + "×");

    const dz = s.rightStickDeadzone !== undefined ? s.rightStickDeadzone : 0.05;
    set("right-deadzone", dz); setText("val-deadzone", parseFloat(dz).toFixed(2));

    setChk("enable-colors",           s.enableColors);
    setChk("enable-draw-sticks",      s.enableDrawSticks);
    setChk("disable-touchcontroller", s.disableTouchController);
    setChk("enable-glow",             s.enableGlow);
}

browser.storage.sync.get(KEYS, (settings) => {
    setFormValues(settings);

    // Live sliders
    const live = (id, valId, fmt) => {
        document.getElementById(id).addEventListener("input", e => {
            document.getElementById(valId).textContent = fmt ? fmt(e.target.value) : e.target.value;
        });
    };
    live("stick-radius",        "val-stick-radius");
    live("button-diameter",     "val-button-diameter");
    live("opacity",             "val-opacity");
    live("right-sensitivity",   "val-right-sens",  v => parseFloat(v).toFixed(2) + "×");
    live("left-sensitivity",    "val-left-sens",   v => parseFloat(v).toFixed(2) + "×");
    live("right-deadzone",      "val-deadzone",    v => parseFloat(v).toFixed(2));

    document.getElementById("apply-button").addEventListener("click", () => {
        const vals = getFormValues();
        browser.storage.sync.set(vals, () => {
            showToast("✓ Aplicado!");
            setTimeout(() => chrome.tabs.reload(), 800);
        });
    });
});
